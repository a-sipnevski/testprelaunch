class IpAddress < ActiveRecord::Base
end
