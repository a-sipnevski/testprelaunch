Rails.application.config.assets.precompile += %w( active_admin.css application.css )
